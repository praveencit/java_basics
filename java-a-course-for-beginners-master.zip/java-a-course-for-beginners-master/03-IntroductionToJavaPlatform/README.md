![](https://raw.githubusercontent.com/in28minutes/java-cheat-sheet/master/images/java-write-once-run-anywhere.png)


# JDK vs JRE vs JVM

- JVM (Java Virtual Machine) runs Java bytecode.
- JRE = JVM + Libraries + Other Components 
- JDK = JRE + Compilers + Debuggers

# 