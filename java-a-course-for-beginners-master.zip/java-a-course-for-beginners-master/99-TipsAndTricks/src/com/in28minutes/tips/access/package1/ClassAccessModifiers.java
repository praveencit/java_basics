package com.in28minutes.tips.access.package1;


//public, protected, (default), private
public class ClassAccessModifiers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassAccessModifiers c = new ClassAccessModifiers();

	}

}
