package com.in28minutes.firstjavaproject;

public class KeyboardShortcuts {
	public static void main(String[] args) {
		int i = 0;
		System.out.println(i);
	}
}
